echo " -------- other tools ------------------------------------ "
sudo pacman -S --noconfirm firefox gedit chromium pluma conky
sudo pacman -S --noconfirm p7zip p7zip-plugins unrar tar rsync

ln -s /usr/bin/clear /usr/bin/cls
echo "completed."
